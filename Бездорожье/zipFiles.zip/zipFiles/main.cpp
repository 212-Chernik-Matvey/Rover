#include"include.h"

int main(){
    control c;
    boundery b(&c);
    b.correct();
    b.DoWork();      
    cout<<"ok"<<endl;
    return 0;   
}