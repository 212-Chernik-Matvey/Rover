#ifndef LOG_H
#define LOG_H

class log {
private:
  double x1; 
  double y1;
  double x2;
  double y2;
  double R;

public:
  log();
  log(double x1, double y1, double x2, double y2, double R);
  void setx1(double newx1);
  void sety1(double newy1);
  void setx2(double newx2);
  void sety2(double newy2);
  void setR(double newR);

double logCalc(point b);
};

void Logs(vector<class::log> &logs);