#include <cmath>
#include <ctime>
#include <fstream>
#include <iostream>
#include <random>
#include <string>
#include <vector>

#include"bell.h"
#include"boundery.h"
#include"control.h"
#include"Field.h"
#include"function.h"
#include"log.h"
#include"parametrs.h"
#include"point.h"
#include"stone.h"
