#include"include.h"

double critic_angle1, critic_angle2;
point A, B;
class Rover{
   protected:
     double pixel;
     vector<point> rover;
     field* surface;
     double angle1;//back
     double angle2;
     double speed;
     double clirence;

   public:
     
     Rover(field* F) : surface(F){
        Porder orderA = F->order_of_point(A);
        int i = orderA.geti();
        int j = orderA.getj();
        pixel = F->GetPixel();
        rover.push_back(A);//p0
        rover.push_back(A + point(0, pixel, 0) +point(0, 0, F->Field[i][j+1].getz()));//p1
        rover.push_back(A + point(pixel, pixel, 0 ) + point(0, 0, F->Field[i+1][j+1].getz()));//p2
        rover.push_back(A + point(pixel, 0, 0) + point(0, 0, F->Field[i+1][j].getz()));//p3
        rover.push_back(A + point(pixel, -pixel, 0) + point(0, 0, F->Field[i+1][j-1].getz()));//p4
        rover.push_back(A + point(0, -pixel, 0) + point(0, 0, F->Field[i][j-1].getz()));//p5
        rover.push_back(A + point(-pixel, -pixel, 0) + point(0, 0, F->Field[i-1][j-1].getz()));//p6
        rover.push_back(A + point(-pixel, 0, 0) + point(0, 0, F->Field[i-1][j].getz()));//p7
        rover.push_back(A + point(-pixel, pixel, 0) + point(0, 0, F->Field[i-1][j+1].getz()));//p8
        angle1 = 0;
        angle2 = 0;
        speed = 4*pixel;
        clirence = pixel/2;
     }

     void ReBuild(point fix){
        Porder orderFix = surface->order_of_point(fix);
        int i = orderFix.geti();
        int j = orderFix.getj();
        rover.clear();
        rover.push_back(fix);//p0
        rover.push_back(fix + point(0, pixel, 0) +  point(0, 0, surface->Field[i][j+1].getz()));//p1
        rover.push_back(fix + point(pixel, pixel, 0 ) + point(0, 0, surface->Field[i+1][j+1].getz()));//p2
        rover.push_back(fix + point(pixel, 0, 0) + point(0, 0, surface->Field[i+1][j].getz()));//p3
        rover.push_back(fix + point(pixel, -pixel, 0) + point(0, 0, surface->Field[i+1][j-1].getz()));//p4
        rover.push_back(fix + point(0, -pixel, 0) + point(0, 0, surface->Field[i][j-1].getz()));//p5
        rover.push_back(fix + point(-pixel, -pixel, 0) + point(0, 0, surface->Field[i-1][j-1].getz()));//p6
        rover.push_back(fix + point(-pixel, 0, 0) + point(0, 0, surfase->Field[i-1][j].getz()));//p7
        rover.push_back(fix + point(-pixel, pixel, 0) + point(0, 0, surface->Field[i-1][j+1].getz()));//p8
     }

     void Move_NN(){
       rover[0]+=point(0,speed,0);
       point fix = rover[0];
       this->ReBuild(fix);
     }  

     void Move_NE(){
       rover[0]+= point(speed, speed, 0);
       point fix = rover[0];
       this->ReBuild(fix);
     }

     void Move_EE(){
        rover[0]+= point(speed, 0, 0);
        point fix = rover[0];
        this->ReBuild(fix);
     }

     void Move_SE(){
        rover[0]+= point(speed, -speed, 0);
        point fix = rover[0];
        this->ReBuild(fix);
     }  

     void Move_SS(){
        rover[0]+= point(0, -speed, 0);
        point fix = rover[0];
        this->ReBuild(fix);
     }     

     void Move_SW(){
        rover[0]+= point(-speed, -speed, 0);
        point fix = rover[0];
        this->ReBuild(fix);
     }

     void Move_WW(){
        rover[0]+= point(-speed, 0, 0);
        point fix = rover[0];
        this->ReBuild(fix);
     }     

     void Move_NW(){
        rover[0]+= point(-speed, speed, 0);
        point fix = rover[0];
        this->ReBuild(fix);
     }

     void Turn_Left(){
        vector<point> buffer1, buffer2;
        point buffer3 = rover[0];
        for(auto i = 1;i < 3; i++){
          buffer1.push_back(rover[i]);
        } 
        for(auto i = 3;i < 9; i++){
          buffer2.push_back(rover[i]);
        }
        rover.clear();
        rover.push_back(buffer3);
        for(auto i = 0; i < buffer2.size(); i++){
          rover.push_back(buffer2[i]);
        }
        for(auto i = 0; i < buffer1.size(); i++){
          rover.push_back(buffer1[i]);
        }
        buffer1.clear();
        buffer2.clear();
     }

     void Turn_Right(){
       vector<point> buffer1, buffer2;
       point buffer3 = rover[0];
       for(auto i = 1; i < 7; i++) 
         buffer1.push_back(rover[i]);
       for(auto i = 7; i < 9; i++)
         buffer2.push_back(rover[i]);
       rover.clear();
       rover.push_back(buffer3);
       for(auto i = 0; i < buffer2.size(); i++)
         rover.push_back(buffer2[i]);
       for(auto i = 0; i < buffer1.size(); i++)
         rover.push_back(buffer1[i]);
       buffer1.clear();
       buffer2.clear();
     }

     void Turn_Around(){
       vector<point> buffer1, buffer2;
       point buffer3 = rover[0];
       for(auto i = 1; i < 5; i++)
         buffer1.push_back(rover[i]);
       for(auto i = 5; i < 9; i++)
         buffer2.push_back(rover[i]);
       rover.clear();
       rover.push_back(buffer3);
       for(auto i = 0; i < buffer2.size(); i++)
         rover.push_back(buffer2[i]);
       for(auto i = 0; i < buffer1.size(); i++)
         rover.push_back(buffer1[i]);
       buffer1.clear();
       buffer2.clear();
     }

     double direction(){
        point v1 = B - A, v2 = rover[1] - rover[0];
        double cosin, sin, normal_v1, normal_v2, scalmult;
        normal_v1 = sqrt(v1.getx()*v1.getx() + v1.gety()*v1.gety());
        normal_v2 = sqrt(v2.getx()*v2.getx() + v2.gety()*v2.gety());
        scalmult = v1.getx()*v2.getx() + v1.gety()*v2.gety();
        cosin = scalmult/(normal_v1*normal_v2);
        return cosin; 
     }

     void change_direction(){
       double cosin = this->direction();
       while(cosin <= 0){
         this->Turn_Left();
         cosin = this->direction();
       }
     }
     

    







     ~Rover(){
       rover.clear();
       delete surface;
     }
  };







}